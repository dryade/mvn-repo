#!/bin/bash

java -Xmx800M -jar chouette-gui-command-2.0.3.jar $*
