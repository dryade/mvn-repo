#!/bin/bash

java -Xmx800M -jar chouette-command-2.0.3.jar $*
